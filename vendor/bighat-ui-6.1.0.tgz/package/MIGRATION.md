# Migration guide

## 4.x → 5.0 — `Table` row actions are an icon button named after the row

### What changed

Each row's actions trigger was a capsule reading "Row actions", forty times
down a column. It is now a round `⋯` icon button whose name carries the row:
"Actions for INV-2046". The name comes from the new `rowLabel` prop, or from
`rowKey` when `rowLabel` is not given.

### What to update

```diff
- screen.getAllByRole('button', { name: 'Row actions' })
+ screen.getAllByRole('button', { name: /^Actions for / })
```

Pass `rowLabel` when the key is not what a reader sees, e.g. an internal id.

## 4.x → 5.0 — `BoardCard` moves with a menu, not a select

### What changed

The card's move control was a native `<select class="bh-board__move-select">`.
It is now a `Menu` whose trigger is `<button class="bh-board__move-trigger">`.
A closed select commits on the first arrow key on Windows, so keyboard users
moved cards they were only looking at.

Nothing changes in how you use `BoardCard`: `moveTargets` and `onMove` are the
same props, called with the same `id`.

### What to update

```bash
rg 'bh-board__move-select' src     # your own CSS or selectors
rg 'Move “.*” to' src               # tests that found the select by its label
```

```diff
- await userEvent.selectOptions(screen.getByLabelText('Move “Invoice INV-2041” to'), 'review');
+ await userEvent.click(screen.getByRole('button', { name: 'Move to… Invoice INV-2041' }));
+ await userEvent.click(screen.getByRole('menuitem', { name: 'In review' }));
```

## 2.x → 3.0 — `variant="danger"` is removed

### What changed

The deprecation announced in 2.0 has closed. `variant="danger"` no longer
exists; it is a TypeScript error rather than a silent fallback.

```diff
- <Button variant="danger">Delete workspace</Button>
+ <Button tone="critical">Delete workspace</Button>
```

### If you are already on 2.x

Nothing may need doing. Every `variant="danger"` in a 2.x codebase has been
printing a deprecation warning in development since the day you upgraded, so
the work is likely finished. To be sure:

```bash
rg 'variant="danger"' src        # expect no matches
npx tsc --noEmit                 # the type error is the backstop
```

### If you skipped 2.x

Do the 1.x → 2.0 rename below first — the scripted replacement still applies —
then upgrade. There is no combined path, because the intermediate version is
where the warning lived, and the warning is what makes the rename safe to do
gradually.

### Why the window was two versions long

`variant="danger"` rendered byte-identically to its replacement for the whole
of 2.x, asserted by a test. That property is what let a team take 2.0 on a
Tuesday and do the rename whenever they got to it — the version bump and the
migration were two separate decisions, which is the only way a team with its
own roadmap can schedule them.

Removing it in 3.0 rather than leaving it forever is the other half of the
bargain. A deprecation that never ends is not a deprecation; it is a second
API you have quietly agreed to maintain.

---

## 1.x → 2.0 — `Button` splits `variant` into `variant` + `tone`

### What changed

`variant="danger"` is deprecated. Use `variant="primary" tone="critical"`.

```diff
- <Button variant="danger">Delete workspace</Button>
+ <Button variant="primary" tone="critical">Delete workspace</Button>
```

`variant` defaults to `primary`, so in practice:

```diff
- <Button variant="danger">Delete</Button>
+ <Button tone="critical">Delete</Button>
```

### Why this was worth a major version

`variant` was doing two jobs. Four of its five values described **visual
weight** — how loud is this button relative to everything else on screen. One
of them, `danger`, described **consequence** — what happens if you press it.

The prop worked right up until someone needed a destructive action that was not
the loudest thing on screen. A delete button inside a row of table actions
should be quiet _and_ destructive, and there was no way to say that. The
workarounds that appeared in product code were the tell:

```tsx
// Three different teams, three different workarounds, none of them theme-safe.
<Button variant="ghost" style={{ color: '#c02a2f' }}>Delete</Button>
<Button variant="secondary" className="destructive-override">Delete</Button>
<Button variant="danger" size="sm">Delete</Button>  // loud, and wrong
```

Splitting the axes makes all nine combinations expressible and removes the
inline overrides, which were also the only places in the codebase referencing a
raw hex value.

### What it costs

One codemod-able rename across every consumer, and a major version bump that
every team has to schedule. That is a real cost and it is the reason this was
not done as a "quick cleanup" — it was proposed, argued for, and accepted with
a deprecation window rather than shipped as a surprise.

### Deprecation timeline

| Version | Behaviour of `variant="danger"`                                           |
| ------- | ------------------------------------------------------------------------- |
| 2.0     | Works. Warns once in development. Renders identically to the replacement. |
| 2.x     | Unchanged.                                                                |
| 3.0     | Removed. TypeScript error.                                                |

The rendered output is byte-identical between the old and new form for the
whole of 2.x — there is a test asserting exactly that, so upgrading cannot
change how anything looks. That is the property that lets a team take 2.0 on a
Tuesday and do the rename whenever they get to it.

### Automated rename

`variant="danger"` has no other meaning in this codebase, so a scripted
replacement is safe:

```bash
# Preview
rg --files-with-matches 'variant="danger"' src

# Apply
rg --files-with-matches 'variant="danger"' src \
  | xargs sed -i '' 's/variant="danger"/variant="primary" tone="critical"/g'
```

Then run your type-check. Anything the script missed — a variant passed through
a variable, a spread prop — surfaces as a deprecation warning in the browser
console the first time that button renders in development.

### If you are blocked

Staying on 1.x is supported until 3.0 ships. What is _not_ supported is
suppressing the warning and skipping the rename: the removal in 3.0 is a
compile error, not a runtime fallback.
